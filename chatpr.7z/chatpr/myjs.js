setTimeout(function () {

    const sendMessageFn = function (event) {
        if (!event.keyCode || event.keyCode === 13) {
            if (document.getElementById('textarea').value) {
                debugger;
                document.getElementById('textarea').value += document.getElementById('txt').value + '\r\n';
            } else {
                document.getElementById('textarea').value = document.getElementById('txt').value + '\r\n';

            }
        }
    };


    const clearMessageFn = function (event) {
        document.getElementById('txt').value = "";
        document.getElementById('textarea').value = "";

    };

document.getElementById('sendMsgBtn').addEventListener('click', sendMessageFn);
document.getElementById('clearMsgBtn').addEventListener('click', clearMessageFn);

document.getElementById('txt').addEventListener('keypress', sendMessageFn);

}, 0);